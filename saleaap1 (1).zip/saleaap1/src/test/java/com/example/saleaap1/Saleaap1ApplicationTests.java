package com.example.saleaap1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Saleaap1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
