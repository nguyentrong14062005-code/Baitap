package com.example.saleaap1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Saleaap1Application {

	public static void main(String[] args) {
		SpringApplication.run(Saleaap1Application.class, args);
	}

}
